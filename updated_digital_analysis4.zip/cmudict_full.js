// CMU Pronouncing Dictionary - placeholder
// Add the full CMU dict object below:
window.cmuDict = {
  // "hello": ["HH","AH0","L","OW1"],
  // ... full dictionary entries ...
};
